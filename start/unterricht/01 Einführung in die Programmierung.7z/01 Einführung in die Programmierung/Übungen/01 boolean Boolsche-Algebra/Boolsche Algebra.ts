//https://de.wikipedia.org/wiki/Logikgatter


// (A und B ) oder (C und D)

const A = true
const B = true
const C = false


let E :boolean

E =  (A && B) || ( A && C )
E





