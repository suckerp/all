


{
    const zahl : number = 35
    const teiler: number = 7

    if(zahl % teiler === 0){
        console.log(`${zahl} ist durch ${teiler} teilbar`)
    } else {
        console.log(`${zahl} ist nicht durch ${teiler} teilbar`)
    }

}
