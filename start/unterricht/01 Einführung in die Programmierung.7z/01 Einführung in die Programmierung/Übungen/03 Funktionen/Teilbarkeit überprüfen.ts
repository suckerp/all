{
    function istTeilbar(zahl:number, teiler:number):boolean{
        return zahl % teiler === 0
    }
    
    
    const teilbar = istTeilbar(4,2)
    teilbar
    
}

