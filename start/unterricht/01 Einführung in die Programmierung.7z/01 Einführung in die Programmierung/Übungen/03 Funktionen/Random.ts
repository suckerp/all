{

    function randomMinMax (min:number, max:number):number{
        return Math.round((Math.random() * (max - min) ) + min)
    }
    
    const zufällig_zwischen_min_und_max = randomMinMax(2,3) 
    zufällig_zwischen_min_und_max

}
